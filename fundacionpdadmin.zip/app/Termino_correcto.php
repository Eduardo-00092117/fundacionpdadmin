<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Termino_correcto extends Model
{
    protected $table = 'termino_correcto';
    protected $fillable = ['nombre'];
}
