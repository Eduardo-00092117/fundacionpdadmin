<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid" id="boletin">

    <div class="card text-center">
        <div class="card-header">
          <ul class="nav nav-tabs card-header-tabs">
            <li class="nav-item">
              <a class="nav-link active" href="/noticias">Noticias</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/formacion">Formación</a>
            </li>
          </ul>
        </div>
        <div class="card-body">
            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
              <div class="carousel-inner">
              <?php
                $cont = 1;
              ?>
              <?php $__currentLoopData = $noticia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cont === 1): ?> 
                  <div class="carousel-item active">
                    <h3 class="card-title text-color-celeste"><?php echo e($pos->titulo); ?></h3>
                    <img src="img/<?php echo e($pos->url_imagen); ?>" class="img-fluid">
                    <div class="textoCarrusel">
                      <p class="card-text"><?php echo e($pos->descripcion); ?></p>
                    </div>
                  </div>
                    <?php
                      $cont = 2;
                    ?>
                <?php else: ?>
                  <div class="carousel-item">
                    <h3 class="card-title text-color-celeste"><?php echo e($pos->titulo); ?></h3>
                    <img src="img/<?php echo e($pos->url_imagen); ?>" class="img-fluid">
                    <div class="textoCarrusel">
                      <p class="card-text"><?php echo e($pos->descripcion); ?></p>
                    </div>
                  </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
            </div>
        </div>
      </div>

</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fundacionpdadmin\resources\views/boletinNoticias.blade.php ENDPATH**/ ?>