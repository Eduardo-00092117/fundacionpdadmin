<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">

    <!---------------Etapa Inicial------------------>
    <div id="desktop">
        <div class="row etapaInicial">
            <div class="col-md" id="aDesarrollo">
                <div>
                    <h1 class="title tc-verde" style="font-size: 3em; text-transform: uppercase;"><?php echo e($area[5]->nombre); ?></h1>
                    <p><?php echo e($area[5]->descripcion); ?></p>     
                </div>
            </div>
            <div class="col-md" id="">
                <img src="img/<?php echo e($area[5]->url_imagen); ?>" alt="">
            </div>
        </div>
    </div>

    <div id="moviles">
        <div class="col  etapaInicial">
            <div class="col-md" id="">
                <img src="img/<?php echo e($area[5]->url_imagen); ?>" alt="">
            </div>
            <div class="col-md" id="aDesarrollo">
                <div>
                    <h1 class="tc-verde" style="font-size: 2em; text-transform: uppercase;"><?php echo e($area[5]->nombre); ?></h1>
                    <p><?php echo e($area[5]->descripcion); ?></p>     
                </div>
            </div>
        </div>
    </div>
    
    <hr class="linea-multicolor" style="width: 100%;">
    <!---------------Segmento 2--------------------->
    <div class="row Acontenedor">
        <div class="col-md Asegmento">
            <div>
                <div class="row">
                    <div class="col">
                        <img src="img/<?php echo e($subarea[22]->url_imagen); ?>" alt="" width="100%">
                    </div>
                </div>
                <div class="row">
                    <div class="col" id="texto1">
                        <p><?php echo e($subarea[22]->titulo); ?></p>
                        <p><?php echo e($subarea[22]->subtitulo); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md Asegmento">
            <div>
                <div class="row">
                    <div class="col">
                        <img src="img/<?php echo e($subarea[23]->url_imagen); ?>" alt="" width="100%">
                    </div>
                </div>
                <div class="row">
                    <div class="col" id="texto2">
                        <p><?php echo e($subarea[23]->titulo); ?></p>
                        <p><?php echo e($subarea[23]->subtitulo); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!---------------Segmento 3--------------------->
    <div class="row Acontenedor">
        <div class="col-md Asegmento">
            <div>
                <div class="row">
                    <div class="col">
                        <img src="img/<?php echo e($subarea[24]->url_imagen); ?>" alt="" width="100%">
                    </div>
                </div>
                <div class="row">
                    <div class="col" id="texto3">
                        <p><?php echo e($subarea[24]->titulo); ?></p>
                        <p><?php echo e($subarea[24]->subtitulo); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md Asegmento">
            <div>
                <div class="row">
                    <div class="col">
                        <img src="img/<?php echo e($subarea[25]->url_imagen); ?>" alt="" width="100%">
                    </div>
                </div>
                <div class="row">
                    <div class="col" id="texto4">
                        <p><?php echo e($subarea[25]->titulo); ?></p>
                        <p><?php echo e($subarea[25]->subtitulo); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!---------------Segmento 4--------------------->
    <div class="row Acontenedor">
        <div class="col-md Asegmento">
            <div>
                <div class="row">
                    <div class="col">
                        <img src="img/<?php echo e($subarea[26]->url_imagen); ?>" alt="" width="100%">
                    </div>
                </div>
                <div class="row">
                    <div class="col" id="texto6">
                        <p><?php echo e($subarea[26]->titulo); ?></p>
                        <p><?php echo e($subarea[26]->subtitulo); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md Asegmento">
            <div>
                <div class="row">
                    <div class="col">
                        <img src="img/<?php echo e($subarea[27]->url_imagen); ?>" alt="" width="100%">
                    </div>
                </div>
                <div class="row">
                    <div class="col" id="texto5">
                        <p><?php echo e($subarea[27]->titulo); ?></p>
                        <p><?php echo e($subarea[27]->subtitulo); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<br>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eduar\Google Drive\Otros archivos\Cursos o Proyectos externos\fundacionpdadmin\resources\views/areaDesarrollo.blade.php ENDPATH**/ ?>