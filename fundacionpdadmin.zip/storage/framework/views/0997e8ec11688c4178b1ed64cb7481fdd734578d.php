<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="card text-center mantenimiento">
        <div class="card-header"></div>
        <div class="card-body">
          <h2 class="card-title tc-rosado">Pagina no disponible</h2>
          <img src="<?php echo e(URL::asset('img/Mantenimiento/mantenimiento.jpg')); ?>">
          <div class="d-flex justify-content-center" style="margin: 1%">
            <div class="spinner-border tc-verde" role="status">
              <span class="visually-hidden"></span>
            </div>
          </div>
        </div>
        <div class="card-footer text-muted"></div>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fundacionpdadmin\resources\views/mantenimiento.blade.php ENDPATH**/ ?>