<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container center asociaciones">
    <h1 class="tc-anaranjado">Asociaciones de
            apoyo</h1>
    <hr class="linea-multicolor linea-asociacion">
    <p class="container-asociacion">En esta sesión prodrán encontrar: los contactos de otras organizaciones que
        trabajan a favor de las personas con
        discapacidad, en El Salvador y en Iberoamérica. Para visitar la página Web o perfil de Facebook de cada
        organización por favor hacer click en el nombre</p>
    <h2 class="tc-rosado">Internacionales</h2>
    <div class="row row-cols-md-2 row-cols-1 card-asociaciones">
        <?php $__currentLoopData = $asociacion_internacional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md">
                            <div>
                                <div> 
                                    <h5><?php echo e($pos->nombre); ?></h5>
                                </div>
                                <div>
                                    <img src="img/<?php echo e($pos->url_logo); ?>" class="img-thumbnail rounded mx-auto d-block">
                                    <p class="card-text"><?php echo e($pos->descripcion); ?></p>
                                </div>
                                <div>
                                    <hr class="linea-asociaciones-card">
                                    <?php if($pos->url_facebook != null): ?>
                                        <div class="asociaciones-redes1">
                                            <a href="<?php echo e($pos->url_facebook); ?>"><i class="fab fa-facebook"></i></a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($pos->telefono != null): ?>
                                        <div class="asociaciones-redes2">
                                            <i class="fas fa-phone"></i> <?php echo e($pos->telefono); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <h2 class="tc-rosado">Nacionales</h2>
    <div class="row row-cols-md-2 row-cols-1 card-asociaciones">
        <?php $__currentLoopData = $asociacion_nacional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md">
                        <div>
                            <div> 
                                <h5><?php echo e($pos->nombre); ?></h5>
                            </div>
                            <div>
                                <img src="img/<?php echo e($pos->url_logo); ?>" class="img-thumbnail rounded mx-auto d-block">
                                <p class="card-text"><?php echo e($pos->descripcion); ?></p>
                            </div>
                            <div>
                                <hr class="linea-asociaciones-card">
                                <?php if($pos->url_facebook != null): ?>
                                    <div class="asociaciones-redes1">
                                        <a href="<?php echo e($pos->url_facebook); ?>"><i class="fab fa-facebook"></i></a>
                                    </div>
                                <?php endif; ?>
                                <?php if($pos->telefono != null): ?>
                                    <div class="asociaciones-redes2">
                                        <i class="fas fa-phone"></i> <?php echo e($pos->telefono); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<br>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php /**PATH C:\Users\eduar\Google Drive\Otros archivos\Cursos o Proyectos externos\fundacionpdadmin\resources\views/asociacionesApoyo.blade.php ENDPATH**/ ?>